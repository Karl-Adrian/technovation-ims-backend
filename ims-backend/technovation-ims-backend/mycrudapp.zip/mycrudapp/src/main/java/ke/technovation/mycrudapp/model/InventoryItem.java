package ke.technovation.mycrudapp.model;

public class InventoryItem {
    private Long id;
    private String name;
    private String description;
    private int quantity;

    // Constructors, getters, and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}

