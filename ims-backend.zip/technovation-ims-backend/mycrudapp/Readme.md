cd target 
scp mycrudapp-0.0.1-SNAPSHOT.jar root@192.168.0.33:/home/davies
qf"&9UhIZo4L0D-Ng"$r996H7
